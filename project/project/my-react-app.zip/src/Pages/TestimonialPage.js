import { Box } from '@chakra-ui/react'
import React from 'react'

const TestimonialPage = () => {
    return (
        <Box>

        </Box>
    )
}

export default TestimonialPage